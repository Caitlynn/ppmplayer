##To do
validate malloc (return null if it doesn't work)
error message(if error, print the error message and quit the program)

## Notes:
User has to install SDL2.0 library before running the program.
Download from here: https://www.libsdl.org/download-2.0.php
