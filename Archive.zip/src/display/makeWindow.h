
#ifndef MAKEWINDOW_H
#define MAKEWINDOW_H
#include "../ppmplayer.h"

#endif